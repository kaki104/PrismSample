﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Input;
using Windows.ApplicationModel;
using Windows.UI.Popups;
using Prism.Commands;
using Prism.Windows.Mvvm;
using Prism.Windows.Navigation;
using PrismSample.Core.Helpers;
using PrismSample.Core.Models;
using PrismSample.Core.Services;

namespace PrismSample.ViewModels
{
    public class MovieViewModel : ViewModelBase
    {
        private SearchRoot _searchResult;
        private IList<Search> _searchs;
        private Search _selectedMovie;
        private readonly INavigationService _navigationService;
        private string _inputMovieTitle;

        public Search SelectedMovie
        {
            get => _selectedMovie;
            set => SetProperty(ref _selectedMovie ,value);
        }

        public ICommand BeginningEditCommand { get; set; }

        public ICommand SelectionChangedCommand { get; set; }

        public ICommand QuerySubmittedCommand { get; set; }

        public ICommand HelpCommand { get; set; }

        public MovieViewModel(INavigationService navigationService)
        {
            _navigationService = navigationService;
            Init();
        }

        private void Init()
        {
            if (DesignMode.DesignMode2Enabled) return;

            BeginningEditCommand = new DelegateCommand(OnBeginningEditCommand);

            SelectionChangedCommand = new DelegateCommand<object>(OnSelectionChangedCommand);

            QuerySubmittedCommand = new DelegateCommand(OnQuerySubmittedCommand);

            HelpCommand = new DelegateCommand(OnHelpCommand);

            PropertyChanged += MovieViewModel_PropertyChanged;

        }

        private async void OnHelpCommand()
        {
            var message = new MessageDialog("Help me!!");
            await message.ShowAsync();
        }

        private async void OnQuerySubmittedCommand()
        {
            await GetMoviesAsync(InputMovieTitle);
        }

        /// <summary>
        /// 입력한 영화 제목
        /// </summary>
        public string InputMovieTitle
        {
            get => _inputMovieTitle;
            set => SetProperty(ref _inputMovieTitle ,value);
        }

        private void OnSelectionChangedCommand(object obj)
        {
            var list = obj as IList;
            if (list == null) return;
            Debug.WriteLine($"SelectionChanged {list.Count}");
        }

        private void OnBeginningEditCommand()
        {
            
        }

        private void MovieViewModel_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case nameof(SelectedMovie):
                    Debug.WriteLine($"SelectedMovie Changed!! {SelectedMovie.Title}");

                    if (SelectedMovie == null) return;

                    _navigationService.Navigate(PageTokens.MovieDetailPage, SelectedMovie.ImdbId);
                    break;
            }
        }

        public override void OnNavigatedTo(NavigatedToEventArgs e, Dictionary<string, object> viewModelState)
        {
            //await GetMoviesAsync();
        }

        private async Task GetMoviesAsync(string movieTitle)
        {
            using (var client = new HttpClient())
            {
                var result = await client.GetStringAsync($"http://www.omdbapi.com/?s={movieTitle}&apikey=32941a88");
                if (string.IsNullOrEmpty(result)) return;

                var searchRoot = await Json.ToObjectAsync<SearchRoot>(result);
                if (searchRoot == null) return;
                _searchResult = searchRoot;
                Searchs = _searchResult.Search?.ToList();
            }
        }
        /// <summary>
        /// 검색 결과
        /// </summary>
        public IList<Search> Searchs
        {
            get => _searchs;
            set => SetProperty(ref _searchs ,value);
        }
    }
}
