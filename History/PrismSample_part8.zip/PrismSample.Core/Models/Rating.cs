﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrismSample.Core.Models
{
    public class Rating
    {
        public string Source { get; set; }
        public string Value { get; set; }
    }

}
