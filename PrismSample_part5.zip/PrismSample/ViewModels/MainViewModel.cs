﻿using System;

using Prism.Windows.Mvvm;

namespace PrismSample.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        public MainViewModel()
        {
        }
    }
}
