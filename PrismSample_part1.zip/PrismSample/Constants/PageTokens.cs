﻿namespace PrismSample
{
    internal static class PageTokens
    {
        public const string MainPage = "Main";
        public const string MasterDetailDetailPage = "MasterDetailDetail";
        public const string MasterDetailPage = "MasterDetail";
        public const string WebViewPage = "WebView";
    }
}
